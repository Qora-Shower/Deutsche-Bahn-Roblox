let deferredPrompt;

window.addEventListener("beforeinstallprompt", (event) => {
  event.preventDefault();
  
  deferredPrompt = event;
  
  document.getElementById("installbtn").
  style.display = "block";
});